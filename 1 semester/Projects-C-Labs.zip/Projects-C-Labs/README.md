all labs for first semester
