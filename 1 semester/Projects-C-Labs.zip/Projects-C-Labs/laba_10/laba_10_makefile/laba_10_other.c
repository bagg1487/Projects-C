#include "laba_10_header.h"
void multipication(float a,float b){printf("%.4f\n", a*b);}
void division (float a,float b){printf("%.4f\n", a/b);}