#include <stdio.h>
int main() {
    //11 - Ближайшая степень двойки к числу
  //  int n;
 //   scanf("%d",&n);
 //   for (int k = 0,m = 1; m <= n; k++, m = m * 2//){
 //       printf("%d %d\n",k+1,m);
 //   }
    //12 Сумма цифр в числе
   // int a,k;
 //   scanf("%d",&a);
 //   for (int n=a, s=0; n!=0; n=n/10){
  //      k=n%10;
  //      s=s+k;
     //   printf("%d %d %d \n",n, k, s);
  //  }
  //13 Степень двойки
 // int n;
 // scanf("%d",n);
 // for (int s=1,i=1; i <= n; i++){
 //     s = s * 2;
  //    printf("%d %d \n", i, s);
//  }
  //14 Проверка числа на четность
 // int n,a;
 // scanf("%d", &a);
 // for (n=2; n<a; n++){
   //  if (a%n==0) break;}
     //if (n==a) printf("Good\n");
  
  //15 Количество делителей числа
//	int a;
//	scanf("%d",&a);
//	for (int s=0,n=2; n<a; n++){
//		if (a%n==0)s++; 
//		if (s==0) puts("Good");break;}

    
}

