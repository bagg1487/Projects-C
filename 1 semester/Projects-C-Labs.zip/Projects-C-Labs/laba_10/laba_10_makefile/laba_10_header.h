#define FUNCTIONS_H
#include <stdio.h>
struct fraction {float a,b;};
void multipication(float a,float b);
void division (float a,float b);

